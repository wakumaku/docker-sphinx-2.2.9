#define SPH_SVN_TAG "rel22"
#define SPH_SVN_REV 5006
#define SPH_SVN_REVSTR "5006"
#define SPH_SVN_TAGREV "rel22-r5006"
